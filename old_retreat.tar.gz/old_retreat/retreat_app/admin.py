from django.contrib import admin
from retreat_app.models import Retreat, User

admin.site.register(Retreat)
